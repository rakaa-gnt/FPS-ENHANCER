SKIPUNZIP=0

ui_print "*******************************"
ui_print "     FPS ENHANCED UNIVERSAL    "
ui_print "           VERSION 1.3         "
ui_print "*******************************"

ui_print "- Upgrading to v1.3..."
ui_print "- Optimizing SQLite Databases..."
ui_print "- Executing System FS Trim..."
ui_print "- Fine-tuning Network Latency..."

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/fpsenhaced 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
