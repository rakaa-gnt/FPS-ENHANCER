#!/system/bin/sh
MODDIR=${0%/*}

# Wait until the system is completely ready
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 5
done

# Exec permission
chmod +x "$MODDIR/fpsenhaced"

# Exec now 
"$MODDIR/fpsenhaced" &
